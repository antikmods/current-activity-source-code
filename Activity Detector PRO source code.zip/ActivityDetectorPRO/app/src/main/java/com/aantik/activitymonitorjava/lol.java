package com.aantik.activitymonitorjava;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
public class lol extends AccessibilityService {

    static {
    System.loadLibrary("capture");
    }

    public static String pkg = "...";
    public static String at = "...";

    private native void onNativeEvent(AccessibilityEvent event);

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    onNativeEvent(event);
    }

    @Override
    public boolean onUnbind(Intent intent) {
    return true;
    }


    @Override
    public void onInterrupt() {}
}
