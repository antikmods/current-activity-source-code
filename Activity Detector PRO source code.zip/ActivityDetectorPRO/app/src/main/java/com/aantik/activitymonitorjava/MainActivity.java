package com.aantik.activitymonitorjava;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.materialswitch.MaterialSwitch;

public class MainActivity extends AppCompatActivity {

    private static final String aj = "antik";
    private static final String bj = "antik_cx";
    private static final int cj = Color.parseColor("#000000");

    private MaterialSwitch dj;
    private View ej;
    private SeekBar fj, gj, hj, ij;

    private int jj, kj, lj, mj;

    private SharedPreferences nj;


    static {
        System.loadLibrary("capture");
    }

    private native boolean nativeIsServiceEnabled(Context ctx, Class<?> clazz);


    @Override
    protected void onCreate(Bundle oj) {
        super.onCreate(oj);
        setContentView(R.layout.activity_main);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                startActivity(intent);
            }
        }

        dj = findViewById(R.id.op);
        ej = findViewById(R.id.nop);
        fj = findViewById(R.id.gok);
        gj = findViewById(R.id.gok2);
        hj = findViewById(R.id.gok3);
        ij = findViewById(R.id.gok4);

        nj = getSharedPreferences(aj, MODE_PRIVATE);

        int pj = nj.getInt(bj, cj);
        mj = Color.alpha(pj);
        jj = Color.red(pj);
        kj = Color.green(pj);
        lj = Color.blue(pj);


        SeekBar.OnSeekBarChangeListener qj = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar rk, int sk, boolean tk) {
                jj = fj.getProgress();
                kj = gj.getProgress();
                lj = hj.getProgress();
                mj = ij.getProgress();

                int uk = Color.argb(mj, jj, kj, lj);
                vl(uk);
                wl(uk);
            }
            @Override public void onStartTrackingTouch(SeekBar rk) {}
            @Override public void onStopTrackingTouch(SeekBar rk) {}
        };
        fj.setOnSeekBarChangeListener(qj);
        gj.setOnSeekBarChangeListener(qj);
        hj.setOnSeekBarChangeListener(qj);
        ij.setOnSeekBarChangeListener(qj);

        // Set progress
        fj.setProgress(jj);
        gj.setProgress(kj);
        hj.setProgress(lj);
        ij.setProgress(mj);

        vl(pj);
        boolean xl = yl(this, lol.class);
        dj.setChecked(xl && Box.isS());
        dj.setOnCheckedChangeListener((rk, sk) -> {
            if (sk) {
                if (yl(this, lol.class)) {
                    Box.sh(this);
                } else {
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            } else {
                if (Box.isS()) Box.hd();
            }
        });
    }
    private void vl(int color) {
        ej.setBackgroundColor(color);

        ColorStateList am = ColorStateList.valueOf(Color.argb(255, Color.red(color), Color.green(color), Color.blue(color)));
        ColorStateList bm = ColorStateList.valueOf(Color.argb(180, Color.red(color), Color.green(color), Color.blue(color)));
        dj.setThumbTintList(am);
        dj.setTrackTintList(bm);

        ColorStateList cm = ColorStateList.valueOf(color);
        fj.setThumbTintList(cm);
        fj.setProgressTintList(cm);
        gj.setThumbTintList(cm);
        gj.setProgressTintList(cm);
        hj.setThumbTintList(cm);
        hj.setProgressTintList(cm);
        ij.setThumbTintList(cm);
        ij.setProgressTintList(cm);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(color);
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(new ColorDrawable(color));
        }
        if (Box.isS()) {
        Box.sbc(color);
        }
    }
    private void wl(int color) {
        nj.edit().putInt(bj, color).apply();
    }
    private boolean yl(Context dm, Class<?> em) {
        return nativeIsServiceEnabled(dm, em);
    }
}
