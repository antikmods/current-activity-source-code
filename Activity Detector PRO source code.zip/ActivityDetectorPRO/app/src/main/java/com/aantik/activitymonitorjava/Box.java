package com.aantik.activitymonitorjava;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.View;
import android.view.WindowManager;

public class Box extends View {

    private Paint dj, ei, io, oj, uj, kj, pj;
    private TextPaint zj;
    private float qj, wj;
    private static WindowManager sj;
    private static WindowManager.LayoutParams xj;
    private static Box cj;
    private static Handler vj;

    private String mj = "...";
    private String nj = "...";

    private int bj;
    private int fj, gj;

    private static int hj = Color.rgb(45, 45, 45);
    private static int lj = Color.argb(180, 40, 40, 40);

    public Box(Context ojc) {
        super(ojc);

        dj = new Paint();
        dj.setColor(hj);

        ei = new Paint();
        ei.setColor(lj);

        io = new Paint();
        io.setColor(Color.WHITE);
        io.setTextSize(42f);
        io.setFakeBoldText(true);

        oj = new Paint();
        oj.setColor(Color.WHITE);
        oj.setTextSize(38f);
        oj.setFakeBoldText(true);

        uj = new Paint();
        uj.setColor(Color.WHITE);
        uj.setTextSize(34f);

        zj = new TextPaint();
        zj.setColor(Color.WHITE);
        zj.setTextSize(34f);

        kj = new Paint();
        kj.setColor(Color.WHITE);
        kj.setStrokeWidth(1.5f);

        pj = new Paint();
        pj.setColor(Color.WHITE);
        pj.setTextSize(26f);
        pj.setAntiAlias(true);
    }

    @Override
    protected void onMeasure(int wmj, int hmj) {
        int w = MeasureSpec.getSize(wmj);
        int valW = w - 320;

        fj = rk(mj, valW);
        gj = rk(nj, valW);

        bj = 80 + (fj + 60) + (gj + 60);

        setMeasuredDimension(w, bj);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int y = 0;
        int pad = 25;

        int divX = pad + 260;

        dj.setColor(hj);
        c.drawRect(0, 0, w, 80, dj);
        c.drawText("Activity Detector PRO", pad, 55, io);
        c.drawText("×", w - 60, 55, oj);
        c.drawText("Made in BD", w - 230, 60, pj);

        y = 80;
        c.drawLine(0, y, w, y, kj);

        int r1 = fj + 60;
        ei.setColor(lj);
        c.drawRect(0, y, w, y + r1, ei);
        c.drawLine(divX, y + 10, divX, y + r1 - 10, kj);
        c.drawText("Package Name:", pad, y + 45, uj);
        al(c, mj, divX + 20, y + 15, w - (divX + 40));
        y += r1;
        c.drawLine(0, y, w, y, kj);

        int r2 = gj + 60;
        ei.setColor(lj);
        c.drawRect(0, y, w, y + r2, ei);
        c.drawLine(divX, y + 10, divX, y + r2 - 10, kj);
        c.drawText("Current Activity:", pad, y + 45, uj);
        al(c, nj, divX + 20, y + 15, w - (divX + 40));
    }

    public void ql(String a, String b) {
        this.mj = a;
        this.nj = b;
        requestLayout();
        invalidate();
    }

    private int al(Canvas c, String t, int x, int y, int mw) {
        StaticLayout sl;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        sl = StaticLayout.Builder.obtain(t, 0, t.length(), zj, mw)
        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
        .build();
        } else {
        sl = new StaticLayout(t, zj, mw,
        Layout.Alignment.ALIGN_NORMAL, 1.0f, 0, false);
        }
        c.save();
        c.translate(x, y);
        sl.draw(c);
        c.restore();
        return sl.getHeight();
    }

    private int rk(String t, int mw) {
        StaticLayout sl;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        sl = StaticLayout.Builder.obtain(t, 0, t.length(), zj, mw)
        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
        .build();
        } else {
        sl = new StaticLayout(t, zj, mw,
        Layout.Alignment.ALIGN_NORMAL, 1.0f, 0, false);
        }
        return sl.getHeight();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                qj = e.getRawX();
                wj = e.getRawY();

                if (e.getX() > getWidth() - 100 && e.getY() < 100) {
                sj.removeView(this);
                cj = null;
                if (vj != null) vj.removeCallbacksAndMessages(null);
                return true;
                }

                int t1 = 80;
                int b1 = t1 + (fj + 60);
                if (e.getY() > t1 && e.getY() < b1) {
                cp("Package Name", mj);
                return true;
                }

                int t2 = 80 + (fj + 60);
                int b2 = t2 + (gj + 60);
                if (e.getY() > t2 && e.getY() < b2) {
                cp("Current Activity", nj);
                return true;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
            float dx = e.getRawX() - qj;
            float dy = e.getRawY() - wj;
            xj.x += dx;
            xj.y += dy;
            sj.updateViewLayout(this, xj);
            qj = e.getRawX();
            wj = e.getRawY();
            return true;
        }
        return super.onTouchEvent(e);
    }

    private void cp(String l, String t) {
    ClipboardManager cb = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    ClipData clip = ClipData.newPlainText(l, t);
    cb.setPrimaryClip(clip);
    }
    public static void sh(Context c) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
    if (!Settings.canDrawOverlays(c)) {
    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + c.getPackageName()));
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    c.startActivity(i);
    return;
    }
    }

    sj = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    xj = new WindowManager.LayoutParams(700, WindowManager.LayoutParams.WRAP_CONTENT, Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);

        xj.x = 0;
        xj.y = 200;
        cj = new Box(c);
        sj.addView(cj, xj);
        vj = new Handler();
        Runnable r = new Runnable() {
            @Override
            public void run() {
                String a = lol.pkg;
                String b = lol.at;
                if (cj != null) {
                cj.ql(a, b);
                }
                vj.postDelayed(this, 0);
            }
        };
        vj.post(r);
    }

    public static boolean isS() {
        return cj != null;
    }
    public static void hd() {
        if (sj != null && cj != null) {
        sj.removeView(cj);
        cj = null;
        }
    }
    public static void sbc(int c) {
        int r = Color.red(c);
        int g = Color.green(c);
        int b = Color.blue(c);
        hj = Color.rgb(r, g, b);
        lj = Color.argb(180, r, g, b);
        if (cj != null) {
        cj.invalidate();
        }
    }

}
