#include <jni.h>
#include <string>
#include <cstring>

extern "C"
JNIEXPORT void JNICALL
Java_com_aantik_activitymonitorjava_lol_onNativeEvent(JNIEnv* env, jobject /*thiz*/, jobject event) {
    jclass eventClass = env->GetObjectClass(event);
    if (!eventClass) return;
    jmethodID getEventType = env->GetMethodID(eventClass, "getEventType", "()I");
    if (!getEventType) return;
    jint eventType = env->CallIntMethod(event, getEventType);
    if (eventType == 32) {
        jmethodID getPackageName = env->GetMethodID(eventClass,"getPackageName", "()Ljava/lang/CharSequence;");
        jmethodID getClassName   = env->GetMethodID(eventClass,"getClassName", "()Ljava/lang/CharSequence;");
        if (!getPackageName || !getClassName) return;
        jobject pkgObj = env->CallObjectMethod(event, getPackageName);
        jobject actObj = env->CallObjectMethod(event, getClassName);
        if (!pkgObj || !actObj) return;
        jclass charSeqClass = env->FindClass("java/lang/CharSequence");
        jmethodID toStringMethod = env->GetMethodID(charSeqClass, "toString", "()Ljava/lang/String;");
        if (!toStringMethod) return;
        jstring pkgStr = (jstring) env->CallObjectMethod(pkgObj, toStringMethod);
        jstring actStr = (jstring) env->CallObjectMethod(actObj, toStringMethod);
        if (!pkgStr || !actStr) return;
        const char* c_pkg = env->GetStringUTFChars(pkgStr, nullptr);
        const char* c_act = env->GetStringUTFChars(actStr, nullptr);
        jclass lolClass = env->FindClass("com/aantik/activitymonitorjava/lol");
        if (!lolClass) return;
        jfieldID pkgField = env->GetStaticFieldID(lolClass, "pkg", "Ljava/lang/String;");
        jfieldID actField = env->GetStaticFieldID(lolClass, "at", "Ljava/lang/String;");
        if (pkgField && actField) {
        jstring newPkg = env->NewStringUTF(c_pkg);
        jstring newAct = env->NewStringUTF(c_act);
        env->SetStaticObjectField(lolClass, pkgField, newPkg);
        env->SetStaticObjectField(lolClass, actField, newAct);
        env->DeleteLocalRef(newPkg);
        env->DeleteLocalRef(newAct);
        }
        env->ReleaseStringUTFChars(pkgStr, c_pkg);
        env->ReleaseStringUTFChars(actStr, c_act);
        env->DeleteLocalRef(pkgStr);
        env->DeleteLocalRef(actStr);
        env->DeleteLocalRef(pkgObj);
        env->DeleteLocalRef(actObj);
    }
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_aantik_activitymonitorjava_MainActivity_nativeIsServiceEnabled(JNIEnv* env, jobject /*thiz*/, jobject ctx, jclass clazz) {
    jclass settingsSecure = env->FindClass("android/provider/Settings$Secure");
    if (!settingsSecure) return JNI_FALSE;
    jmethodID getInt = env->GetStaticMethodID(settingsSecure, "getInt","(Landroid/content/ContentResolver;Ljava/lang/String;)I");
    jmethodID getString = env->GetStaticMethodID(settingsSecure, "getString","(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    if (!getInt || !getString) return JNI_FALSE;
    jclass contextClass = env->GetObjectClass(ctx);
    jmethodID getResolver = env->GetMethodID(contextClass, "getContentResolver","()Landroid/content/ContentResolver;");
    jobject resolver = env->CallObjectMethod(ctx, getResolver);
    if (!resolver) return JNI_FALSE;
    jstring keyEnabled = env->NewStringUTF("accessibility_enabled");
    jint enabled = env->CallStaticIntMethod(settingsSecure, getInt, resolver, keyEnabled);
    env->DeleteLocalRef(keyEnabled);
    if (enabled != 1) {return JNI_FALSE;}
    jstring keyServices = env->NewStringUTF("enabled_accessibility_services");
    jstring servicesStr = (jstring) env->CallStaticObjectMethod(settingsSecure, getString, resolver, keyServices);
    env->DeleteLocalRef(keyServices);
    if (servicesStr == nullptr) return JNI_FALSE;
    const char* servicesCStr = env->GetStringUTFChars(servicesStr, nullptr);
    if (!servicesCStr) return JNI_FALSE;
    jclass clazzClass = env->GetObjectClass(clazz);
    jmethodID getName = env->GetMethodID(clazzClass, "getName", "()Ljava/lang/String;");
    jstring clazzName = (jstring) env->CallObjectMethod(clazz, getName);
    const char* clazzCStr = env->GetStringUTFChars(clazzName, nullptr);
    jclass ctxClass = env->GetObjectClass(ctx);
    jmethodID getPkgName = env->GetMethodID(ctxClass, "getPackageName", "()Ljava/lang/String;");
    jstring pkgName = (jstring) env->CallObjectMethod(ctx, getPkgName);
    const char* pkgCStr = env->GetStringUTFChars(pkgName, nullptr);
    std::string fullService = std::string(pkgCStr) + "/" + clazzCStr;
    bool found = (strstr(servicesCStr, fullService.c_str()) != nullptr);
    env->ReleaseStringUTFChars(servicesStr, servicesCStr);
    env->ReleaseStringUTFChars(clazzName, clazzCStr);
    env->ReleaseStringUTFChars(pkgName, pkgCStr);
    env->DeleteLocalRef(servicesStr);
    env->DeleteLocalRef(clazzName);
    env->DeleteLocalRef(pkgName);
    return found ? JNI_TRUE : JNI_FALSE;
}
